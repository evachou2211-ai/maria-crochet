PETITES MAILLES — SITE PRÊT À PUBLIER

Le fichier index.html est le site de la boutique.
Il contient :
- les modèles de bonnets
- choix de couleur
- choix des perles
- calcul du total
- Wave / Orange Money / paiement à la livraison
- nom + numéro client
- commande WhatsApp vers 77 336 00 38

Pour obtenir un vrai lien public, le dossier doit être envoyé sur un hébergeur web.
